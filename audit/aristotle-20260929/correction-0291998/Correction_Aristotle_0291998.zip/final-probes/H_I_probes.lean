import RelationalPerimeter
open ConstitutiveSearch ConstitutiveSearch.EndogenousDecomposition ConstitutiveSearch.Extensive
open ConstitutiveSearch.RelationalExtensive

namespace AuditProbe

/-- H/A probe: a binary opening whose four relation families are all `Unit`. -/
def unitRelationStage (source : Nat) : RelationalOpeningStage Nat source (source + 1) :=
  { Role := Unit, Position := Fin 2, Occurrence := Fin 2, Provenance := Unit
    SourceRelation := fun _ _ => Unit
    FormationRelation := fun _ _ => Unit
    TargetRelation := fun _ _ => Unit
    ProvenanceRelation := fun _ _ _ => Unit
    role := (), provenance := ()
    sourceWitness := (), targetWitness := ()
    positionDecEq := inferInstance
    positionFrontier := constructiveFinRange 2
    positionComplete := constructiveFinRange_complete
    positionNodup := constructiveFinRange_nodup 2
    realize := id, classify := id
    realize_classify := fun _ => rfl, classify_realize := fun _ => rfl
    formationAgreement := fun _ => (), provenanceAgreement := fun _ => () }

def unitRelationHistory : (count source : Nat) → DependentRelationalRoleHistory Nat source count
  | 0, source => .nil source
  | count + 1, source => .step (unitRelationStage source) (unitRelationHistory count (source + 1))

theorem unitRelationHistory_uniform : (count source : Nat) →
    UniformLocalArity (unitRelationHistory count source) 2
  | 0, _ => True.intro
  | count + 1, source => ⟨constructiveFinRange_length 2, unitRelationHistory_uniform count (source + 1)⟩

theorem unitRelationHistory_nontrivial : (count source : Nat) →
    AtLeastBinaryLocalArity (unitRelationHistory count source)
  | 0, _ => True.intro
  | count + 1, source => by
      constructor
      · change 2 ≤ (constructiveFinRange 2).length
        rw [constructiveFinRange_length]
        exact Nat.le_refl 2
      · exact unitRelationHistory_nontrivial count (source + 1)

def unitRelationFamily : BinaryRelationalRoleExtensiveFamily :=
  { State := Nat, Problem := fun _ => Unit, initialState := fun _ => 0
    stageCount := fun {index} _ => index + 1
    producedHistory := fun {index} _ => unitRelationHistory (index + 1) 0
    nontrivialOpenings := fun {index} _ => unitRelationHistory_nontrivial (index + 1) 0
    unboundedIndex := id, unboundedProblem := fun _ => ()
    unboundedStages := fun bound => Nat.le_succ bound
    binaryOpenings := fun {index} _ => unitRelationHistory_uniform (index + 1) 0 }

/-- The class theorem applies verbatim to the all-`Unit` relational member. -/
theorem unitFamily_iff (index : Nat) (regime : ObligationRegime (unitRelationFamily.sourceCarrier (index := index) ())) :
    regime.frontier.length = 2 ^ unitRelationFamily.stageCount (index := index) () ↔ Function.Injective regime.carry :=
  binaryClass_fullWidthExactlyInjective unitRelationFamily () regime

theorem unitFamily_width (index : Nat) :
    (unitRelationFamily.sourceCarrier (index := index) ()).frontier.length = 2 ^ (index + 1) :=
  unitRelationFamily.sourceWidth_eq_twoPow ()

/-- I probe: the statement of `extensiveMultiplicity_doesNotForceFullOperationalWidth`
is provable from an arbitrary constant (Unit) regime, with no reference to execution. -/
def unitRegime (input : Nat) : ObligationRegime (publicRoleProfileFiniteCarrier input) :=
  { Obligation := Unit
    decEq := fun a b => by cases a; cases b; exact isTrue rfl
    frontier := [()]
    complete := fun o => by cases o; exact .head []
    nodup := .cons (fun _ m _ => nomatch m) .nil
    carry := fun _ => ()
    carry_surjective := fun o => by
      cases o
      exact ⟨defaultRoleOccurrenceProfile (publicRelationalConstitutiveRoles input), rfl⟩ }

theorem notForced_withoutExecution (input : Nat) :
    ¬ (∀ regime : ObligationRegime (publicRoleProfileFiniteCarrier input),
      regime.frontier.length = 2 ^ (input + 1)) := by
  intro h
  have one : 1 = 2 ^ (input + 1) := h (unitRegime input)
  exact Nat.ne_of_lt (Constructive.two_pow_strictly_grows (Nat.zero_lt_succ input)) one

/-- G probe: the fibre `iff` of the bridge also holds for the unrelated Unit regime,
because all produced targets converge. -/
theorem unitRegime_fibres (input : Nat) (p q : RoleOccurrenceProfile (publicRelationalConstitutiveRoles input)) :
    (unitRegime input).carry p = (unitRegime input).carry q ↔
      Nonempty (OperationallyCoDetermined (publicCertificateNormalization input) p q) :=
  ⟨fun _ => ⟨(publicCertificateNormalization input).coDeterminationOfTargetEq p q
      ((publicCertificateNormalization input).targets_converge p q)⟩, fun _ => rfl⟩

/-- A probe: the four "agreements" of every public profile follow from the role
fields alone, without consuming any `RoleConstitutionEvidence`. -/
theorem constitution_without_evidence (input : Nat) :
    ∀ p : RoleOccurrenceProfile (publicRelationalConstitutiveRoles input), RoleSemantics.ProfileConstitution p :=
  RoleSemantics.profileConstitution

/-- D probe: the normalized target does not depend on the source profile at all. -/
theorem target_independent_of_source (input : Nat) (p : RoleOccurrenceProfile (publicRelationalConstitutiveRoles input)) :
    (publicCertificateNormalization input).target p =
      retainedExecutedOperationalTargetProfile (publicCausalOperationalExecution input).stagewiseDecomposition.reduction :=
  (publicCertificateNormalization input).target_exact p

end AuditProbe

#print axioms AuditProbe.unitFamily_iff
#print axioms AuditProbe.notForced_withoutExecution
#print axioms AuditProbe.unitRegime_fibres
#print axioms AuditProbe.constitution_without_evidence
#eval (AuditProbe.unitRelationFamily.sourceCarrier (index := 3) ()).frontier.length
