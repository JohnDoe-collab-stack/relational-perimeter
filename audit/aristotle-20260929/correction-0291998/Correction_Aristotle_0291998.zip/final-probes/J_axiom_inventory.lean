import Lean
import RelationalPerimeter
open Lean Elab Command

run_cmd do
  let env ← getEnv
  let roots := #[`SegmentedResidualRole, `AbstractSegmentedTurning, `ExactTypeTransport,
    `StrongPerimetralTurning, `RelationalPerimeter]
  let mut total := 0
  let mut withAx := 0
  let mut lines : Array String := #[]
  for (name, _) in env.constants.map₁.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[idx.toNat]!
    unless roots.any (fun r => r.isPrefixOf mod) do continue
    total := total + 1
    let axs ← liftCoreM <| Lean.collectAxioms name
    if axs.size > 0 then
      withAx := withAx + 1
      lines := lines.push s!"{mod} :: {name} :: {axs.toList}"
  for l in lines.qsort (· < ·) do
    logInfo l
  logInfo s!"TOTAL_PROJECT_CONSTANTS={total} WITH_AXIOMS={withAx}"
