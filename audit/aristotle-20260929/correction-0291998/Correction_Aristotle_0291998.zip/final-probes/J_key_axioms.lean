import Lean
import RelationalPerimeter
import Tests.AristotleCorrectionRegression
import Tests.DeepPreservationRegression
import Tests.ProductionTimelineRegression
open Lean Elab Command

run_cmd do
  let env ← getEnv
  let mods := #[`RelationalPerimeter.Computation.EndogenousOperationalDecomposition,
    `RelationalPerimeter.Computation.ConstitutiveSearch.EndogenousDecomposition.ConstitutiveExtensiveSeparation,
    `RelationalPerimeter.Computation.ConstitutiveSearch.EndogenousDecomposition.ExecutedFeedbackBridge,
    `RelationalPerimeter.Computation.ConstitutiveSearch.EndogenousDecomposition.ExecutedCausalNormalization,
    `RelationalPerimeter.Computation.ConstitutiveSearch.RelationalRoleExtensiveFamily,
    `RelationalPerimeter.Computation.ConstitutiveSearch.FiniteExtensiveAddressing,
    `RelationalPerimeter.Computation.ConstitutiveSearch.EndogenousDecomposition.CausalOperationalExecution,
    `RelationalPerimeter.Computation.ConstitutiveSearch.EndogenousDecomposition.RolewiseOperationalStatus,
    `RelationalPerimeter.Computation.ConstitutiveSearch.EndogenousDecomposition.RelationalConstitutiveRoles,
    `RelationalPerimeter.Computation.ConstitutiveSearch.EndogenousDecomposition.RoleIndexedProfiles,
    `RelationalPerimeter.Computation.ConstitutiveSearch.SAT.GeneratedStructuralContext,
    `RelationalPerimeter.Computation.ConstitutiveSearch.SemanticImage,
    `Tests.AristotleCorrectionRegression, `Tests.DeepPreservationRegression,
    `Tests.ProductionTimelineRegression]
  let mut total := 0
  let mut bad := 0
  for (name, _) in env.constants.map₁.toList do
    let some idx := env.getModuleIdxFor? name | continue
    let mod := env.header.moduleNames[idx.toNat]!
    unless mods.contains mod do continue
    if name.isInternal then continue
    let s := name.toString
    if s.endsWith "injEq" || s.endsWith "eq_def" || s.endsWith "congr_simp" then continue
    total := total + 1
    let axs ← liftCoreM <| Lean.collectAxioms name
    if axs.size > 0 then
      bad := bad + 1
      logInfo s!"{mod} :: {name} :: {axs.toList}"
  logInfo s!"KEY_MODULE_NON_AUX_CONSTANTS={total} WITH_AXIOMS={bad}"

#print axioms RelationalPerimeter.Computation.EndogenousOperationalDecomposition.endogenous_production_and_width_separation
