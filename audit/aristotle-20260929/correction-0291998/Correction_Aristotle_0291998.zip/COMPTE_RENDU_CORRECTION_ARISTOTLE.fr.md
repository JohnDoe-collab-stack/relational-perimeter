# Correction après l’audit Aristotle — livraison vérifiée

## 1. État exact de la livraison

Le lot de correction est implémenté et compilé. La vérification sur une copie Git propre et la campagne ciblée décrite ci-dessous sont terminées. **Cela ne vaut pas un verdict positif de l’ensemble du protocole adversarial A–J : plusieurs mutations équivalentes ou reconstructions de garanties survivent.** Le verdict historique `EXACT TARGET REQUIRES CORRECTIONS` n’est pas réécrit.

| Référence | Valeur |
|---|---|
| Commit de code vérifié | `02919988b97d959253b9104ec20372f39ca2f69d` |
| Arbre de code | `55cadef8a0bf1c2a42606d83076ea844a62745c3` |
| Parent | `13eed60eac867cacfc4d4a0fddca33334ea882ed` |
| Ancienne cible scientifique d’Aristotle | `1ca8e89ed02eacc71eb70efa1ccab84985fb8ace` |
| Branche locale | `chatgpt/aristotle-correction-20260929` |
| Compilateur | Lean 4.33.1, commit `819816b2e0a3bf405af45ae5c7af2491d8f5bee6` |
| État de publication de ce lot | Commit local ; aucun push ni merge |

Ce document est le compte rendu unique de la correction. Ce n’est ni un nouveau prompt Aristotle ni une modification de son rapport.

## 2. Corrections effectivement intégrées, dans l’ordre des dépendances

### 2.1 Formation et origine des données

`GeneratedChildFormation`, dans `SAT/GeneratedStructuralContext.lean`, constitue une formation indexée par le parent, la décision, sa fraîcheur et l’enfant engendré. Son élimination fournit l’égalité de réalisation ; `generated_exact` rattache sa provenance au constructeur `StructuralGeneratedFrom.child`. Le constructeur ne demande aucun transport opérationnel. `parent_impossible` exclut de faire passer le parent pour son propre nouvel enfant.

`RoleFormationAgreement` utilise cette formation. Dans `RelationalConstitutiveRoles.lean`, les états source/cible et la provenance ne sont plus des copies librement stockées avec des certificats supplémentaires : ce sont des projections de l’étape indexée. Les accords de réalisation dérivés sont nommés comme tels. La génération structurelle n’est pas confondue avec la relation opérationnelle découverte.

**Limite précise :** cette correction ne démontre pas l’indispensabilité logique des quatre familles aval en tant que représentations séparées. M01, M02 et la variante du porteur réalisé éprouvent encore leur reconstruction depuis des données plus riches. Leur survie reste visible dans la table, sans être maquillée en rejet.

### 2.2 Statuts locaux, action et composition

Le nouveau module `RolewiseOperationalStatus.lean` construit une politique sur les profils déjà constitués. Le statut `none` conserve les deux occurrences ; `some transport` porte un véritable transport préservant et autorise leur absorption. L’action sur les continuations est définie séparément de sa preuve de préservation.

L’image locale est calculée par `computedTargetImageRegime` sur les occurrences finies. Il n’est pas ajouté d’égalité décidable sur l’espace fonctionnel complet des continuations. `History.fibres` caractérise les fibres avant toute hypothèse de convergence. `History.width` établit, pour toute histoire de statuts :

```text
largeur de la frontière composée = 2 ^ pendingCount
```

Les régressions vérifient les cas 4, 2 et 1 sur les mêmes deux rôles : deux ouvertures en attente, une absorption, deux absorptions. Ces cas sont des comparaisons de politique sur une histoire, non trois nouvelles exécutions SAT. `pending_occurrences_not_grouped` interdit précisément une fusion injustifiée dans le cas en attente.

Pour l’exécution publique, les statuts proviennent des licences effectivement stockées dans la réduction. `returnedAct_exact` et `executed_action_exact` rattachent leur action à celle de l’interpréteur existant sur **toute** charge structurelle. L’état tout absorbé possède `pendingCount = 0`, d’où la largeur un.

### 2.3 Régime public et admission

`producedTargetFrontier` et la frontière du régime public sont désormais construits à partir de la frontière de cette politique exécutée. `regimeWidth_eq_statusWidth` et `width_exact` raccordent la lecture de largeur au résultat de la composition locale. Les cibles et leurs traces restent celles de la normalisation existante ; le théorème de convergence n’a pas été supprimé pour artificiellement distinguer des valeurs égales.

`SemanticImage.Admission` sépare invariant, accord sur les données canoniques, préservation universelle et réflexion. `AdmittedImageValue` sépare l’appartenance à l’image et sa spécification. Le consommateur générique ne reçoit pas une réduction SAT riche. Le paramètre d’autorisation inutilisé a été retiré du type concret `AuthorizedProducedTargetObligation` ; son champ de spécification est conservé et consommé dans la version de référence.

Les contre-modèles `no_admission_from_convergence` et `no_usable_image_from_true` prouvent que convergence canonique et appartenance à l’image ne suffisent pas à la garantie sémantique universelle. **Ils ne prétendent pas rendre impossible la reconstruction de cette garantie depuis une réduction concrète qui la contient encore.** Cette reconstruction est précisément testée séparément.

### 2.4 Ordre de production observé

La production endogène et le feedback existants sont réutilisés. `OperationalProductionProgram` décrit les primitives de découverte, application et décomposition. Son interprète calcule la valeur et la trace. Le producteur spécialisé et l’exécuteur récursif sont prouvés égaux à cette interprétation ; l’effacement instrumenté redonne l’exécution antérieure.

`operationalProductionTimeline_exact` établit l’ordre des événements aux frontières de ces primitives. `ProductionTimelineRegression.delayedTwo` effectue réellement l’étape suivante avant la première décomposition : sa valeur finale est la même, mais `delayed_fails_order` prouve que sa trace viole l’ordre requis. Cette contre-épreuve est distincte de l’ancienne M04, qui relisait seulement une histoire de longueur un.

**Portée :** c’est un contrat d’ordre dans le modèle de primitives, non une preuve du temps machine, de l’ordre de toute réduction Lean ni de l’absence de calcul dissimulé dans un argument arbitraire. La fixture historique de récursion mutuelle non terminante reste catégorisée « terminaison », et non preuve générale de causalité.

### 2.5 Conclusion publique et généralité

`EndogenousDecompositionAndWidth` conserve les propriétés antérieures et ajoute le contrat d’ordre, l’admission, l’origine de la largeur dans les statuts et l’accord de leur action avec l’action portée. Les difficultés d’élaboration ont été traitées par une factorisation des types de certificats, sans ajout d’axiome ni suppression des conclusions publiques.

`executedAdmittedRegime_notFullWidth` nomme le régime public admis, avec son admission et sa largeur non pleine. Le lemme qui réfute simplement « tous les régimes ont la pleine largeur » reste une conséquence cardinalement plus faible ; il n’est plus le seul énoncé désigné par cette partie de la conclusion.

Le porteur source reste partagé définitionnellement. Le théorème de classe demeure général : pour toute famille binaire, tout problème et tout régime surjectif concerné, pleine largeur exactement `2^stageCount` si et seulement si `carry` est injective. Le cas public conserve `n = input + 1`, `2^n` profils, une obligation, des profils distincts portés ensemble et une borne transitoire de deux. Le critère demeure l’acceptation point par point des continuations locales ; aucune affectation globale commune ni borne universelle de temps ou de mémoire n’est ajoutée.

## 3. Vérification propre et couverture des tests

Une copie distincte, `verification-final`, a été vérifiée au commit de code indiqué. `lake clean` laisse zéro `.olean`. Toutes les commandes suivantes terminent avec code zéro et aucun diagnostic d’erreur, d’avertissement ou de dépendance axiomatique dans les sorties contrôlées.

| Commande | Résultat |
|---|---|
| `lean --version`, `lake --version` | Versions enregistrées |
| `lake clean` | Réussi ; zéro `.olean` restant |
| `lake build +RelationalPerimeter` | Réussi ; 131 tâches |
| `lake build` | Réussi ; 146 tâches |
| `bash scripts/verify.sh` | Réussi ; 144 fichiers Lean et 19 fixtures |
| `pwsh -NoProfile -File scripts/verify.ps1` | Réussi ; mêmes 144 fichiers et 19 fixtures |
| `git diff --check` | Réussi |
| Intégrité avant/après | 234 fichiers inchangés ; checkout propre |

Les deux scripts lisent maintenant `scripts/expected-failures.tsv`. Ils refusent une fixture non inventoriée, absente ou déclarée plusieurs fois. Les 19 fixtures sont exécutées une fois chacune sur chaque surface. Les quatorze diagnostics précédents sont conservés ; les cinq attentes manquantes sont ajoutées, avec une catégorie explicite.

`test-expected-failure-gates.py` vérifie huit scénarios sur deux surfaces, soit **16 contrôles de vérificateur réussis** : témoin positif, fichier non inventorié, entrée orpheline, doublon, fixture devenue compilable, diagnostic incorrect, fichier manquant et interruption. Ces essais partagent délibérément les bibliothèques déjà compilées : ils vérifient le contrôleur, pas une compilation scientifique propre. Ils sont distincts des mutations de la section suivante.

L’inventaire transitif des modules centraux et des nouvelles régressions relève **1 231 déclarations non auxiliaires selon le filtre de la sonde, zéro dépendance axiomatique**. Le point d’entrée public est contrôlé explicitement. L’inventaire plus large relève 14 721 constantes du projet ; 359 auxiliaires générés dépendent de `propext` ou `Quot.sound` (356 et 3). Ils ne sont pas confondus avec un usage dans les preuves auditées. Les sources exactes des sondes et leurs sorties sont jointes.

## 4. Campagne ciblée achevée

Chaque variante part du même commit de code. Pour chacune : patch final, compilation propre de la racine, compilation complète, Bash, PowerShell, contrôle du diff et empreintes avant/après. Les deux premières commandes de version sont également enregistrées. Aucun timeout n’est compté comme rejet. Aucun ancien journal Aristotle n’est utilisé comme résultat de cette campagne.

Les trois expériences restées absentes de l’audit reçu sont ici présentes : remplacement par le porteur réalisé, retrait profond de l’accord de formule et remplacement de la garantie portée par `True`. Leur portée exacte est donnée ci-dessous : retirer une enveloppe et reconstituer ses témoins ne retire pas toute l’origine constitutive.

**Bilan : 16 variantes, 9 survivantes et 7 rejetées dans l’essai.** Les codes sont, dans l’ordre : `clean / racine / totalité / Bash / PowerShell / diff`.

| Variante | Contrôle | Résultat | Codes | Portée exacte |
|---|---|---|---|---|
| `M01-four-derived-families-Unit` | A | SURVIT | `0/0/0/0/0/0` | Quatre familles aval remplacées par Unit ; la formation des occurrences et les données indexées sont conservées. |
| `M02-ignore-derived-evidence` | A | SURVIT | `0/0/0/0/0/0` | Copie de preuve ignorée ; accord de formation repris depuis l’occurrence réalisée. |
| `A-raw-realized-carrier` | A | SURVIT | `0/0/0/0/0/0` | Retour au porteur réalisé stage.Occurrence ; les témoins sont reconstruits depuis la même étape. Ce n’est pas un effacement de toute formation. |
| `M05-root-tail` | C | REJETÉE DANS CET ESSAI | `0/1/1/1/1/0` | Suite repartant de la racine ; perte des indices imposés par l’état produit. |
| `M06-root-context` | C | REJETÉE DANS CET ESSAI | `0/1/1/1/1/0` | Contexte racine substitué au contexte produit ; incompatibilité des indices de la suite. |
| `C-real-future-reordering` | C | REJETÉE DANS CET ESSAI | `0/1/1/1/1/0` | Exécution d’une véritable étape suivante avant la première décomposition. Le contrat chronologique est faux à deux étapes, même si la valeur finale est égale. |
| `M07-action-constant` | D | REJETÉE DANS CET ESSAI | `0/1/1/1/1/0` | Action totale remplacée par une sortie canonique ; le contrat sur les continuations arbitraires n’est plus satisfait. |
| `M08-prescribed-canonical-target` | D | SURVIT | `0/0/0/0/0/0` | Sortie canonique prescrite, puis accord avec l’action démontré. L’action totale reste inchangée. |
| `M09a-reconstruct-preservation` | E | SURVIT | `0/0/0/0/0/0` | Préservation reconstruite depuis les licences de la réduction ; la garantie n’est pas retirée à sa source. |
| `M09b-reconstruct-separation` | E | SURVIT | `0/0/0/0/0/0` | Distinction reconstruite depuis ces mêmes licences ; les profils restent distincts. |
| `E-deep-formula-agreement` | E | REJETÉE DANS CET ESSAI | `0/1/1/1/1/0` | Accord de formule de la relation remplacé par True ; la carte structurelle reste définie mais le transport universel de l’acceptation n’est plus justifiable. Contre-modèle SAT compilé séparément. |
| `M11-reconstruct-authorization` | F | SURVIT | `0/0/0/0/0/0` | Argument d’autorisation ignoré ; toutes ses garanties sont reconstruites depuis la réduction conservée. |
| `F-True-generic-guarantee` | F | REJETÉE DANS CET ESSAI | `0/1/1/1/1/0` | Spécification de l’obligation générique remplacée par True ; aucun run concret n’est disponible pour reconstruire les garanties universelles. |
| `F-True-public-reconstructed` | F | SURVIT | `0/0/0/0/0/0` | Garantie portée par l’obligation concrète remplacée par True, puis reconstruite depuis la normalisation. À distinguer de la suppression dans l’interface générique. |
| `G-pending-constant-carry` | G | REJETÉE DANS CET ESSAI | `0/1/1/1/1/0` | Toutes les ouvertures regroupées, même celles en attente : largeur deux et fibres exactes du cas sans transport sont perdues. |
| `M12-constant-executed-carry` | F/G | SURVIT | `0/0/0/0/0/0` | Portage constant vers l’ancrage dans l’instance convergente. Les traces sont transportées en utilisant la convergence déjà prouvée. |

Les erreurs aval provoquées par un échec amont ne sont pas comptées comme plusieurs rejets indépendants. La classification « rejetée dans l’essai » ne prouve pas à elle seule l’impossibilité de toute preuve alternative. Les motifs de fond disposent ici de contrôles distincts : indices de la suite, contre-exemple d’ordre à deux étapes, contrat de l’action arbitraire, contre-modèle SAT de préservation, contre-modèle d’admission et distinction des occurrences en attente. Les premiers diagnostics exacts sont conservés dans `results.json` et les journaux complets.

Les variantes survivantes ne sont pas des succès de rejet. En particulier, remplacer la garantie concrète par `True` et la reconstruire depuis la normalisation montre que **la garantie stockée à cet endroit reste dispensable**. Le contre-modèle de l’interface générique ne ferme pas cette exigence forte sur l’interface concrète. De même, prescrire la sortie canonique puis prouver son accord reste possible ; l’observation chronologique des trois primitives ne distingue pas toutes les manières de calculer cette sortie interne.

## 5. Ce qui est terminé et ce qui ne peut pas être déclaré validé

Sont terminés : l’intégration compilée des corrections décrites ; la couverture effective des 19 fixtures ; les 16 tests des vérificateurs ; la vérification propre sur les deux surfaces ; les contre-modèles ; les 16 variantes ciblées avec résultats et empreintes.

Ne sont pas déclarés acquis : l’interdiction de toute représentation alternative des témoins ou du porteur ; l’indispensabilité de chaque copie d’autorisation ; le rejet de toute réécriture extensionnellement équivalente d’une cible ou d’un `carry` convergent ; l’ordre de toute évaluation Lean extérieure au modèle de primitives. Les mutations qui survivent empêchent d’attribuer un verdict global positif au protocole fort inchangé.

Cette campagne n’est pas la reproduction exhaustive de tous les cas historiques A–J sur le nouveau SHA : notamment la variante historique exacte M04 de longueur un, H01/H02 sur le parent, chacune des suppressions historiques M03 et le remplacement intégral du régime par `Unit` ne sont pas revendiqués comme de nouveaux essais complets ici. Les sondes historiques de classe `Unit`, de non-nécessité faible et de fibres ont en revanche été recompilées ; elles restent valides et sont conservées comme telles.

La conclusion correcte est donc : **le lot de correction et sa validation ciblée sont livrés ; la certification intégrale de l’objectif par le protocole fort reste non acquise.** Cela ne nie pas les preuves de production endogène, de préservation et de largeur conservées dans cette version.

## 6. Pièces et reproduction

Le dossier de travail complet, sur la machine autorisée, est :

```text
/home/frederick/constitutive-aristotle-correction-9b3_f2v7/
  work/                         branche de code, propre au SHA indiqué
  verification-final/           copie propre vérifiée
  frozen-evidence/              journaux et empreintes de la référence
  gate-selftests-complete/       16 contrôles des vérificateurs
  mutations-final/<variante>/   patch, copie jetable, journaux et résultats
  final-probes/                 sondes d’axiomes et de portée
  delivery-final/               rapport, résultats structurés, patch et archive
```

L’archive technique de livraison contient ce compte rendu, le patch du code, un bundle Git incrémental depuis `13eed60…`, les résultats structurés, les journaux de référence et de chaque mutation, leurs patches finaux, les sondes et leurs sorties. Elle ne contient ni les `.olean`, ni les caches de compilation, ni des identifiants d’authentification. Les copies complètes des variantes restent dans le dossier de travail ; elles sont reproductibles depuis le SHA et leurs patches.

Exemple de reproduction sur cette machine, dans une nouvelle copie :

```bash
set -euo pipefail
export PATH=/home/frederick/.elan/toolchains/leanprover--lean4---v4.33.1/bin:/home/frederick/constitutive-objective-implementation-hx1wpxuu/tools/powershell-7.4.6:$PATH
JOB=/home/frederick/constitutive-aristotle-correction-9b3_f2v7
CHECK="$(mktemp -d)"
git clone "$JOB/work" "$CHECK/repo"
cd "$CHECK/repo"
git checkout --detach 02919988b97d959253b9104ec20372f39ca2f69d
lake clean
lake build +RelationalPerimeter
lake build
bash scripts/verify.sh
pwsh -NoProfile -File scripts/verify.ps1
python3 scripts/test-expected-failure-gates.py --output "$CHECK/gate-tests"
git diff --check
test -z "$(git status --porcelain)"
```

Pour une mutation, créer une autre copie au même SHA, appliquer son `final.patch` avec `git apply`, puis exécuter `verify_frozen.py --work <copie> --output <journaux-extérieurs> --case <identifiant>`. Le script conserve séparément stdout, stderr, codes et intégrité. Ne jamais appliquer ces patches à la branche de livraison.

## 7. Provenance du compte rendu

Base documentaire : préparation de correction en 406 lignes, rapport Aristotle fourni en 334 lignes et pièces associées, documents de méthode français/anglais déjà lus intégralement pendant la préparation. La correction ne remplace ni leur cadre interne ni leurs limites. Les références techniques de ce compte rendu sont les définitions, preuves et régressions au SHA indiqué, les sorties du compilateur et les résultats de cette campagne. Les limites originales de lecture ou d’environnement d’Aristotle ne sont pas présentées comme résolues par son propre audit.

Le compte rendu n’attribue aucune certification indépendante à ce travail de correction. Aucun prompt supplémentaire n’a été créé ; aucune fusion dans `main` n’a été effectuée.
