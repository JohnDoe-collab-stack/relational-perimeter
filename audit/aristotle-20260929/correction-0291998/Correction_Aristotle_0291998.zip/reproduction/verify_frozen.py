#!/usr/bin/env python3
from pathlib import Path
import argparse, subprocess, os, json, hashlib, time, signal
p=argparse.ArgumentParser()
p.add_argument('--work',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--case',required=True)
a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=True)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=a.work,text=True).strip()
def inventory():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],cwd=a.work,text=True).splitlines()
    return {s:hashlib.sha256((a.work/s).read_bytes()).hexdigest() for s in names if (a.work/s).is_file()}
before=inventory(); (a.output/'sha256-before.json').write_text(json.dumps(before,indent=2))
record={'case':a.case,'base':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'commands':[]}
commands=[('toolchain',['lean','--version']),('lake-version',['lake','--version']),('clean',['lake','clean']),('public-root',['lake','build','+RelationalPerimeter']),('all-targets',['lake','build']),('bash',['bash','scripts/verify.sh']),('powershell',['pwsh','-NoProfile','-File','scripts/verify.ps1']),('diff-check',['git','diff','--check'])]
for name,cmd in commands:
    started=time.monotonic(); out=a.output/(name+'.stdout'); err=a.output/(name+'.stderr')
    timed_out=False
    with out.open('w') as stdout, err.open('w') as stderr:
        proc=subprocess.Popen(cmd,cwd=a.work,stdout=stdout,stderr=stderr,start_new_session=True)
        try: code=proc.wait(timeout=1200)
        except subprocess.TimeoutExpired:
            timed_out=True; os.killpg(proc.pid,signal.SIGTERM)
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL); proc.wait()
            code=proc.returncode
    text=out.read_text()+err.read_text()
    diagnostics=[x for x in text.splitlines() if 'error:' in x or 'warning:' in x or 'depends on axioms:' in x or 'sorryAx' in x]
    result={'name':name,'command':cmd,'exit_code':code,'seconds':round(time.monotonic()-started,3),'timeout':timed_out,'diagnostics':diagnostics,'stdout':out.name,'stderr':err.name}
    if name=='clean': result['remaining_oleans']=len(list((a.work/'.lake/build').rglob('*.olean')))
    record['commands'].append(result)
    (a.output/'results.json').write_text(json.dumps(record,indent=2,ensure_ascii=False))
    print(a.case,name,code,'diagnostics',len(diagnostics),flush=True)
after=inventory(); (a.output/'sha256-after.json').write_text(json.dumps(after,indent=2))
record.update(integrity_unchanged=(before==after),tracked_files=len(before),status_after=git('status','--porcelain'),all_pass=all(x['exit_code']==0 and not x['timeout'] and not x['diagnostics'] for x in record['commands']))
(a.output/'results.json').write_text(json.dumps(record,indent=2,ensure_ascii=False))
print(a.case,'FINISHED',record['all_pass'],'INTEGRITY',record['integrity_unchanged'],flush=True)
