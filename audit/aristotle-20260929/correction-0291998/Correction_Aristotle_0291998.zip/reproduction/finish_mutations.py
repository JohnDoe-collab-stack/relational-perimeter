from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess, json
job=Path('/home/frederick/constitutive-aristotle-correction-9b3_f2v7')
cases=['M09b-reconstruct-separation', 'M11-reconstruct-authorization', 'F-True-public-reconstructed', 'G-pending-constant-carry', 'M12-constant-executed-carry', 'E-deep-formula-agreement']
def run(case):
 out=job/'logs'/('mutation-'+case+'.log')
 result=job/'mutations-final'/case/'verification/results.json'
 if result.exists() and 'integrity_unchanged' in json.loads(result.read_text()): return (case,'already finished')
 with out.open('w') as log:
  cmd=['python3',str(job/'verify_frozen.py'),'--work',str(job/'mutations-final'/case/'work'),'--output',str(job/'mutations-final'/case/'verification'),'--case',case]
  p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print(case,'runner exit',p.returncode,flush=True)
 return (case,p.returncode)
with ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(run,cases))
(job/'finish_mutations_results.json').write_text(json.dumps(results,indent=2))
print('ALL_REMAINING_FINISHED',flush=True)
